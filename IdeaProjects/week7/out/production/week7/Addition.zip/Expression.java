public abstract class Expression {
    /**
     * hi.
     *
     * @return hi
     */
    public abstract double evaluate();

    /**
     * là một lớp trừu tượng để đại diện cho các phép tính, con số (sự biểu lộ).
     *
     * @return hi
     */
    public abstract String toString();
}