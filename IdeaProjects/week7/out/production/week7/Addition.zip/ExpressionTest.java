public class ExpressionTest {
    /**
     * Main method.
     */
    public static void main(String[] args) {
        Numeral numberal10 = new Numeral(10);
        Square square10 = new Square(numberal10);
        Numeral numberal3 = new Numeral(3);
        Numeral numberal4 = new Numeral(4);
        Subtraction subtraction1 = new Subtraction(square10, numberal3);
        Multiplication multiplication1 = new Multiplication(numberal4, numberal3);
        Addition addition1 = new Addition(subtraction1, multiplication1);
        Square square1 = new Square(addition1);
        System.out.println(square1);
    }
}
